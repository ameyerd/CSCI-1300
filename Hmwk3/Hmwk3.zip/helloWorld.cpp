/*  CS1300 Spring 2019
    Author: Amey Erdenebileg
    Recitation: 304 - Shudong Hao
    Cloud 9 Workspace Editor Link: https://ide.c9.io/ameyerd/csci1300
    Homework 3 - Problem 1
*/

#include <iostream>
using namespace std;

/* 
 * Algorithm: output "Hello, World"
 *  1. Use "cout" to output "Hello, World!"
 * Input parameters: none
 * Output : "Hello, World!"
 * Returns: nothing
*/

int main() {
    // test 1
    // expected output
    // "Hello, World"
    cout << "Hello, World!" << endl;
}