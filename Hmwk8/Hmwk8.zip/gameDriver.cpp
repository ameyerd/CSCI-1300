// CS1300 Spring 2019
// Author: Amey Erdenebileg
// Recitation: 304 - Shudong Hao
// Cloud9 Workspace Editor Link: https://ide.c9.io/ameyerd/csci1300
// Hmwk 8 - Problem 4

#include <iostream>
#include <vector>
#include <fstream>
#include "Team.h"
#include "Player.h"
using namespace std;

/*
* Algorithm: takes two input vectors and returns a vector that combines the two vectors
*            by alternating between values
* 1. 
* 2.
* 3. 
* 4. 
* Input parameters: 
* Output (prints to screen): 
* Returns: 
*/
string game(Team team1, Team team2) {
    
    if (team1.getNumPlayers() < 4 || team2.getNumPlayers() < 4) {
        return "forfeit";
    }
    else{
        string winner;
        double team1Total = 0;
        double team2Total = 0;
    
        for(int i = 0; i < 4; i++) {
            double tPoints = team1.getPlayerPoints(i);
            team1Total += tPoints;
        }
        
        for (int k = 0; k < 4; k++) {
            double t2Points = team2.getPlayerPoints(k);
            team2Total += t2Points;
        }
        
        if (team1Total > team2Total) {
            winner = team1.getTeamName();
        }
        else if (team2Total > team1Total) {
            winner = team2.getTeamName();
        }
        else if (team2Total == team1Total) {
            return "draw";
        }
        return winner;
    }
}

int main() {
    // g++ gameDriver.cpp Team.cpp Player.cpp -std=c++11
    
    // Using roster1.txt and roster2.txt
    //  from Moodle
    Team team1("Seg Faultline");
    team1.readRoster("roster1.txt");
    Team team2("Team Maim");
    team2.readRoster("roster2.txt");
    string winner = game(team1, team2);
    cout << "The winner is: " << winner << endl;
    
    cout << endl;
    
    // Using roster2.txt from Moodle
    Team team3("Hurt Shoebox");
    team3.readRoster("roster00.txt");
    Team team4("Team Maim");
    team2.readRoster("roster2.txt");
    string winer = game(team3, team4);
    cout << "The winner is: " << winer << endl;
}